﻿namespace BotecoTDS07
{
    partial class FrmVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmVenda));
            this.btn_LocalizarPV = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comb_Cliente = new System.Windows.Forms.ComboBox();
            this.txt_IdVenda = new System.Windows.Forms.TextBox();
            this.dgv_Produtos = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comb_Produto = new System.Windows.Forms.ComboBox();
            this.txt_IdProduto = new System.Windows.Forms.TextBox();
            this.txt_Quantidade = new System.Windows.Forms.TextBox();
            this.lbl_Estoque = new System.Windows.Forms.Label();
            this.btn_AtualizarP = new System.Windows.Forms.Button();
            this.btn_NovoPedido = new System.Windows.Forms.Button();
            this.btn_ExcluirItem = new System.Windows.Forms.Button();
            this.btn_EditarItem = new System.Windows.Forms.Button();
            this.btn_NovoItem = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_Total = new System.Windows.Forms.TextBox();
            this.btn_Fechar = new System.Windows.Forms.Button();
            this.btn_FinalPedido = new System.Windows.Forms.Button();
            this.btn_FinalVenda = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_ValorUni = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Produtos)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_LocalizarPV
            // 
            this.btn_LocalizarPV.BackColor = System.Drawing.Color.White;
            this.btn_LocalizarPV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LocalizarPV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LocalizarPV.ForeColor = System.Drawing.Color.DarkGreen;
            this.btn_LocalizarPV.Location = new System.Drawing.Point(216, 18);
            this.btn_LocalizarPV.Name = "btn_LocalizarPV";
            this.btn_LocalizarPV.Size = new System.Drawing.Size(203, 39);
            this.btn_LocalizarPV.TabIndex = 0;
            this.btn_LocalizarPV.Text = "LOCALIZAR PEDIDO / VENDA";
            this.btn_LocalizarPV.UseVisualStyleBackColor = false;
            this.btn_LocalizarPV.Click += new System.EventHandler(this.btn_LocalizarPV_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "ID Venda";
            // 
            // comb_Cliente
            // 
            this.comb_Cliente.BackColor = System.Drawing.Color.White;
            this.comb_Cliente.FormattingEnabled = true;
            this.comb_Cliente.Location = new System.Drawing.Point(15, 76);
            this.comb_Cliente.Name = "comb_Cliente";
            this.comb_Cliente.Size = new System.Drawing.Size(419, 21);
            this.comb_Cliente.TabIndex = 2;
            // 
            // txt_IdVenda
            // 
            this.txt_IdVenda.BackColor = System.Drawing.Color.White;
            this.txt_IdVenda.Location = new System.Drawing.Point(15, 28);
            this.txt_IdVenda.Name = "txt_IdVenda";
            this.txt_IdVenda.Size = new System.Drawing.Size(195, 20);
            this.txt_IdVenda.TabIndex = 3;
            // 
            // dgv_Produtos
            // 
            this.dgv_Produtos.AllowUserToAddRows = false;
            this.dgv_Produtos.AllowUserToDeleteRows = false;
            this.dgv_Produtos.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.dgv_Produtos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Produtos.Location = new System.Drawing.Point(15, 371);
            this.dgv_Produtos.Name = "dgv_Produtos";
            this.dgv_Produtos.ReadOnly = true;
            this.dgv_Produtos.Size = new System.Drawing.Size(575, 132);
            this.dgv_Produtos.TabIndex = 4;
            this.dgv_Produtos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Produtos_CellClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "Cliente";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Produto";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "ID Produto";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Quantidade";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 259);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "Estoque:";
            // 
            // comb_Produto
            // 
            this.comb_Produto.BackColor = System.Drawing.Color.White;
            this.comb_Produto.FormattingEnabled = true;
            this.comb_Produto.Location = new System.Drawing.Point(15, 126);
            this.comb_Produto.Name = "comb_Produto";
            this.comb_Produto.Size = new System.Drawing.Size(419, 21);
            this.comb_Produto.TabIndex = 10;
            this.comb_Produto.SelectedIndexChanged += new System.EventHandler(this.comb_Produto_SelectedIndexChanged);
            // 
            // txt_IdProduto
            // 
            this.txt_IdProduto.BackColor = System.Drawing.Color.White;
            this.txt_IdProduto.Location = new System.Drawing.Point(15, 176);
            this.txt_IdProduto.Name = "txt_IdProduto";
            this.txt_IdProduto.Size = new System.Drawing.Size(195, 20);
            this.txt_IdProduto.TabIndex = 11;
            // 
            // txt_Quantidade
            // 
            this.txt_Quantidade.BackColor = System.Drawing.Color.White;
            this.txt_Quantidade.Location = new System.Drawing.Point(15, 226);
            this.txt_Quantidade.Name = "txt_Quantidade";
            this.txt_Quantidade.Size = new System.Drawing.Size(195, 20);
            this.txt_Quantidade.TabIndex = 12;
            this.txt_Quantidade.Leave += new System.EventHandler(this.txt_Quantidade_Leave);
            // 
            // lbl_Estoque
            // 
            this.lbl_Estoque.AutoSize = true;
            this.lbl_Estoque.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Estoque.Location = new System.Drawing.Point(77, 288);
            this.lbl_Estoque.Name = "lbl_Estoque";
            this.lbl_Estoque.Size = new System.Drawing.Size(0, 37);
            this.lbl_Estoque.TabIndex = 13;
            // 
            // btn_AtualizarP
            // 
            this.btn_AtualizarP.BackColor = System.Drawing.Color.White;
            this.btn_AtualizarP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AtualizarP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AtualizarP.Location = new System.Drawing.Point(445, 116);
            this.btn_AtualizarP.Name = "btn_AtualizarP";
            this.btn_AtualizarP.Size = new System.Drawing.Size(145, 39);
            this.btn_AtualizarP.TabIndex = 17;
            this.btn_AtualizarP.Text = "ATUALIZAR PEDIDO";
            this.btn_AtualizarP.UseVisualStyleBackColor = false;
            this.btn_AtualizarP.Click += new System.EventHandler(this.btn_AtualizarP_Click);
            // 
            // btn_NovoPedido
            // 
            this.btn_NovoPedido.BackColor = System.Drawing.Color.White;
            this.btn_NovoPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_NovoPedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NovoPedido.Location = new System.Drawing.Point(445, 66);
            this.btn_NovoPedido.Name = "btn_NovoPedido";
            this.btn_NovoPedido.Size = new System.Drawing.Size(145, 39);
            this.btn_NovoPedido.TabIndex = 18;
            this.btn_NovoPedido.Text = "NOVO PEDIDO";
            this.btn_NovoPedido.UseVisualStyleBackColor = false;
            this.btn_NovoPedido.Click += new System.EventHandler(this.btn_NovoPedido_Click);
            // 
            // btn_ExcluirItem
            // 
            this.btn_ExcluirItem.BackColor = System.Drawing.Color.White;
            this.btn_ExcluirItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ExcluirItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ExcluirItem.ForeColor = System.Drawing.Color.Red;
            this.btn_ExcluirItem.Location = new System.Drawing.Point(260, 307);
            this.btn_ExcluirItem.Name = "btn_ExcluirItem";
            this.btn_ExcluirItem.Size = new System.Drawing.Size(145, 39);
            this.btn_ExcluirItem.TabIndex = 19;
            this.btn_ExcluirItem.Text = "EXCLUIR ITEM";
            this.btn_ExcluirItem.UseVisualStyleBackColor = false;
            this.btn_ExcluirItem.Click += new System.EventHandler(this.btn_ExcluirItem_Click);
            // 
            // btn_EditarItem
            // 
            this.btn_EditarItem.BackColor = System.Drawing.Color.White;
            this.btn_EditarItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EditarItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EditarItem.Location = new System.Drawing.Point(260, 247);
            this.btn_EditarItem.Name = "btn_EditarItem";
            this.btn_EditarItem.Size = new System.Drawing.Size(145, 39);
            this.btn_EditarItem.TabIndex = 20;
            this.btn_EditarItem.Text = "EDITAR ITEM";
            this.btn_EditarItem.UseVisualStyleBackColor = false;
            this.btn_EditarItem.Click += new System.EventHandler(this.btn_EditarItem_Click);
            // 
            // btn_NovoItem
            // 
            this.btn_NovoItem.BackColor = System.Drawing.Color.White;
            this.btn_NovoItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_NovoItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_NovoItem.Location = new System.Drawing.Point(260, 186);
            this.btn_NovoItem.Name = "btn_NovoItem";
            this.btn_NovoItem.Size = new System.Drawing.Size(145, 39);
            this.btn_NovoItem.TabIndex = 21;
            this.btn_NovoItem.Text = "NOVO ITEM";
            this.btn_NovoItem.UseVisualStyleBackColor = false;
            this.btn_NovoItem.Click += new System.EventHandler(this.btn_NovoItem_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(294, 527);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 15);
            this.label7.TabIndex = 22;
            this.label7.Text = "Total R$";
            // 
            // txt_Total
            // 
            this.txt_Total.BackColor = System.Drawing.Color.White;
            this.txt_Total.Location = new System.Drawing.Point(361, 527);
            this.txt_Total.Name = "txt_Total";
            this.txt_Total.Size = new System.Drawing.Size(229, 20);
            this.txt_Total.TabIndex = 23;
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.BackColor = System.Drawing.Color.Red;
            this.btn_Fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Fechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Fechar.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.btn_Fechar.Location = new System.Drawing.Point(101, 571);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(145, 39);
            this.btn_Fechar.TabIndex = 24;
            this.btn_Fechar.Text = "FECHAR";
            this.btn_Fechar.UseVisualStyleBackColor = false;
            this.btn_Fechar.Click += new System.EventHandler(this.btn_Fechar_Click);
            // 
            // btn_FinalPedido
            // 
            this.btn_FinalPedido.BackColor = System.Drawing.Color.White;
            this.btn_FinalPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_FinalPedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FinalPedido.Location = new System.Drawing.Point(274, 571);
            this.btn_FinalPedido.Name = "btn_FinalPedido";
            this.btn_FinalPedido.Size = new System.Drawing.Size(145, 39);
            this.btn_FinalPedido.TabIndex = 25;
            this.btn_FinalPedido.Text = "FINALIZAR PEDIDO";
            this.btn_FinalPedido.UseVisualStyleBackColor = false;
            this.btn_FinalPedido.Click += new System.EventHandler(this.btn_FinalPedido_Click);
            // 
            // btn_FinalVenda
            // 
            this.btn_FinalVenda.BackColor = System.Drawing.Color.White;
            this.btn_FinalVenda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_FinalVenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FinalVenda.Location = new System.Drawing.Point(445, 571);
            this.btn_FinalVenda.Name = "btn_FinalVenda";
            this.btn_FinalVenda.Size = new System.Drawing.Size(145, 39);
            this.btn_FinalVenda.TabIndex = 26;
            this.btn_FinalVenda.Text = "FINALIZAR VENDA";
            this.btn_FinalVenda.UseVisualStyleBackColor = false;
            this.btn_FinalVenda.Click += new System.EventHandler(this.btn_FinalVenda_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(442, 310);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 15);
            this.label8.TabIndex = 27;
            this.label8.Text = "Valor R$";
            // 
            // txt_ValorUni
            // 
            this.txt_ValorUni.BackColor = System.Drawing.Color.White;
            this.txt_ValorUni.Location = new System.Drawing.Point(445, 326);
            this.txt_ValorUni.Name = "txt_ValorUni";
            this.txt_ValorUni.Size = new System.Drawing.Size(145, 20);
            this.txt_ValorUni.TabIndex = 28;
            // 
            // FrmVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(604, 625);
            this.Controls.Add(this.txt_ValorUni);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btn_FinalVenda);
            this.Controls.Add(this.btn_FinalPedido);
            this.Controls.Add(this.btn_Fechar);
            this.Controls.Add(this.txt_Total);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn_NovoItem);
            this.Controls.Add(this.btn_EditarItem);
            this.Controls.Add(this.btn_ExcluirItem);
            this.Controls.Add(this.btn_NovoPedido);
            this.Controls.Add(this.btn_AtualizarP);
            this.Controls.Add(this.lbl_Estoque);
            this.Controls.Add(this.txt_Quantidade);
            this.Controls.Add(this.txt_IdProduto);
            this.Controls.Add(this.comb_Produto);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgv_Produtos);
            this.Controls.Add(this.txt_IdVenda);
            this.Controls.Add(this.comb_Cliente);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_LocalizarPV);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmVenda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Venda";
            this.Load += new System.EventHandler(this.FrmVenda_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Produtos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_LocalizarPV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comb_Cliente;
        private System.Windows.Forms.TextBox txt_IdVenda;
        private System.Windows.Forms.DataGridView dgv_Produtos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comb_Produto;
        private System.Windows.Forms.TextBox txt_IdProduto;
        private System.Windows.Forms.TextBox txt_Quantidade;
        private System.Windows.Forms.Label lbl_Estoque;
        private System.Windows.Forms.Button btn_AtualizarP;
        private System.Windows.Forms.Button btn_NovoPedido;
        private System.Windows.Forms.Button btn_ExcluirItem;
        private System.Windows.Forms.Button btn_EditarItem;
        private System.Windows.Forms.Button btn_NovoItem;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_Total;
        private System.Windows.Forms.Button btn_Fechar;
        private System.Windows.Forms.Button btn_FinalPedido;
        private System.Windows.Forms.Button btn_FinalVenda;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_ValorUni;
    }
}