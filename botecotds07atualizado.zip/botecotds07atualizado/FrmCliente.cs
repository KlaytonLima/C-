﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BotecoTDS07
{
    public partial class FrmCliente : Form
    {
        public FrmCliente()
        {
            InitializeComponent();
        }

        private void btn_Localizar_Click(object sender, EventArgs e)
        {
            if(txt_Id.Text == "")
            {
                MessageBox.Show("Por favor, digite um ID válido!!!");
            } 
            else
            {
                int Id = Convert.ToInt32(txt_Id.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Localizar(Id);
                txt_Nome.Text = cliente.nome;
                txt_Cpf.Text = cliente.cpf;
                txt_DataNascimento.Text = cliente.data_nascimento;
                txt_Celular.Text = cliente.celular;
                btn_Atualizar.Enabled = true;
                btn_Excluir.Enabled = true;
            } 
        }

        private void btn_Inserir_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_Nome.Text == "" && txt_Cpf.Text == "" && txt_DataNascimento.Text == "" && txt_Celular.Text == "")
                {
                    MessageBox.Show("Por favor, preencha o formulário!", "Campos Obrigatórios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.txt_Nome.Focus();
                }
                else
                {
                    Cliente cliente = new Cliente();
                    if (cliente.RegistroRepetido(txt_Nome.Text, txt_Cpf.Text, txt_Celular.Text) != false)
                    {
                        MessageBox.Show("Este cliente já existe em nossa base de dados!", "Cliente Repetido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txt_Nome.Text = "";
                        txt_Cpf.Text = "";
                        txt_DataNascimento.Text = "";
                        txt_Celular.Text = "";
                        this.txt_Nome.Focus();

                    }
                    else
                    {
                        cliente.Inserir(txt_Nome.Text, txt_Cpf.Text, txt_DataNascimento.Text, txt_Celular.Text);
                        MessageBox.Show("Cliente cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        List<Cliente> clientes = cliente.listapessoas();
                        dgv_Cliente.DataSource = clientes;
                        txt_Nome.Text = "";
                        txt_Cpf.Text = "";
                        txt_DataNascimento.Text = "";
                        txt_Celular.Text = "";
                        this.txt_Nome.Focus();
                    }
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btn_Fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(txt_Id.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Excluir(Id);
                MessageBox.Show("Cliente excluído com sucesso!", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> clientes = cliente.listapessoas();
                dgv_Cliente.DataSource = clientes;
                txt_Nome.Text = "";
                txt_Cpf.Text = "";
                txt_DataNascimento.Text = "";
                txt_Celular.Text = "";
                this.txt_Nome.Focus();
                btn_Atualizar.Enabled = false;
                btn_Excluir.Enabled = false;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgv_Cliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgv_Cliente.Rows[e.RowIndex];
                row.Selected = true;
                txt_Id.Text = row.Cells[0].Value.ToString();
                txt_Nome.Text = row.Cells[1].Value.ToString();
                txt_Cpf.Text = row.Cells[2].Value.ToString();
                txt_DataNascimento.Text = row.Cells[3].ToString();
                txt_Celular.Text = row.Cells[4].ToString();
            }
        }
    

    private void btn_Atualizar_Click(object sender, EventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(txt_Id.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Atualizar(Id, txt_Nome.Text, txt_Cpf.Text, txt_DataNascimento.Text, txt_Celular.Text);
                MessageBox.Show("Cliente atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> clientes = cliente.listapessoas();
                dgv_Cliente.DataSource = clientes;
                txt_Nome.Text = "";
                txt_Cpf.Text = "";
                txt_DataNascimento.Text = "";
                txt_Celular.Text = "";
                this.txt_Nome.Focus();
                btn_Atualizar.Enabled = false;
                btn_Excluir.Enabled = false;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmCliente_Load(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            List<Cliente> pessoas = cliente.listapessoas();
            dgv_Cliente.DataSource = pessoas;
            btn_Atualizar.Enabled = false;
            btn_Excluir.Enabled = false;
        }
    }
}
