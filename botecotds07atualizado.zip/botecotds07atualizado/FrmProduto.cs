﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BotecoTDS07
{
    public partial class FrmProduto : Form
    {
        public FrmProduto()
        {
            InitializeComponent();
        }

        private void btn_InserirProduto_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_NomeProduto.Text == "" && txt_TipoProduto.Text == "" && txt_Quantidade.Text == "" && txt_Preco.Text == "")
                {
                    MessageBox.Show("Por favor, preencha o formulário!", "Campos Obrigatórios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.txt_NomeProduto.Focus();
                }
                else
                {
                    Produto produto = new Produto();
                    if (produto.RegistroRepetido(txt_NomeProduto.Text, txt_TipoProduto.Text) != false)
                    {
                        MessageBox.Show("Este produto já existe em nossa base de dados!", "Produto Repetido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txt_NomeProduto.Text = "";
                        txt_TipoProduto.Text = "";
                        txt_Quantidade.Text = "";
                        txt_Preco.Text = "";
                        this.txt_NomeProduto.Focus();

                    }
                    else
                    {
                        produto.Inserir(txt_NomeProduto.Text, txt_TipoProduto.Text, txt_Quantidade.Text, txt_Preco.Text);
                        MessageBox.Show("Produto cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        List<Produto> produtos = produto.listaproduto();
                        dgv_Produto.DataSource = produtos;
                        txt_NomeProduto.Text = "";
                        txt_TipoProduto.Text = "";
                        txt_Quantidade.Text = "";
                        txt_Preco.Text = "";
                        this.txt_NomeProduto.Focus();
                    }
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_AtualizarProduto_Click(object sender, EventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(txt_IdProduto.Text.Trim());
                Produto produto = new Produto();
                produto.Atualizar(Id, txt_NomeProduto.Text, txt_TipoProduto.Text, txt_Quantidade.Text, txt_Preco.Text);
                MessageBox.Show("Produto atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Produto> produtos = produto.listaproduto();
                dgv_Produto.DataSource = produtos;
                txt_NomeProduto.Text = "";
                txt_TipoProduto.Text = "";
                txt_Quantidade.Text = "";
                txt_Preco.Text = "";
                this.txt_NomeProduto.Focus();
                btn_AtualizarProduto.Enabled = false;
                btn_ExcluirProduto.Enabled = false;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_ExcluirProduto_Click(object sender, EventArgs e)
        {
            
                try
                {
                    int Id = Convert.ToInt32(txt_IdProduto.Text.Trim());
                    Produto produto = new Produto();
                    produto.Excluir(Id);
                    MessageBox.Show("Produto excluído com sucesso!", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    List<Produto> produtos = produto.listaproduto();
                    dgv_Produto.DataSource = produtos;
                    txt_NomeProduto.Text = "";
                    txt_TipoProduto.Text = "";
                    txt_Quantidade.Text = "";
                    txt_Preco.Text = "";
                    this.txt_NomeProduto.Focus();
                    btn_AtualizarProduto.Enabled = false;
                    btn_ExcluirProduto.Enabled = false;
                }
                catch (Exception er)
                {
                    MessageBox.Show(er.Message, "Erro!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            
        }

        private void btn_Fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgv_Produto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgv_Produto.Rows[e.RowIndex];
                row.Selected = true;
                txt_IdProduto.Text = row.Cells[0].Value.ToString();
                txt_NomeProduto.Text = row.Cells[1].Value.ToString();
                txt_TipoProduto.Text = row.Cells[2].Value.ToString();
                txt_Quantidade.Text = row.Cells[3].Value.ToString();
                txt_Preco.Text = row.Cells[4].Value.ToString();
            }
        }

        private void btn_Localizar_Click(object sender, EventArgs e)
        {
           
            if (txt_IdProduto.Text == "")
            {
                MessageBox.Show("Por favor, digite um ID válido!!!");
            }
            else
            {
                int Id = Convert.ToInt32(txt_IdProduto.Text.Trim());
                Produto produto = new Produto();
                produto.Localizar(Id);
                txt_NomeProduto.Text = produto.nome;
                txt_TipoProduto.Text = produto.tipo;
                txt_Quantidade.Text = produto.quantidade;
                txt_Preco.Text = produto.preco;
                btn_AtualizarProduto.Enabled = true;
                btn_ExcluirProduto.Enabled = true;
            }
            


        }

        private void FrmProduto_Load(object sender, EventArgs e)
        {
          
                Produto produto = new Produto();
                List<Produto> produtos = produto.listaproduto();
                dgv_Produto.DataSource = produtos;
                btn_AtualizarProduto.Enabled = false;
                btn_ExcluirProduto.Enabled = false;
            
        }
    }
}
