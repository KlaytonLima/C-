﻿namespace BotecoTDS07
{
    partial class frm_Funcionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Funcionario));
            this.label1 = new System.Windows.Forms.Label();
            this.txt_IdFuncionario = new System.Windows.Forms.TextBox();
            this.btn_LocalizarFuncionario = new System.Windows.Forms.Button();
            this.dgv_Funcionario = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_NomeFuncionario = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_GeneroFuncionario = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_CpfFuncionario = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_DataFuncionario = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_CelularFuncionario = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_CepFuncionario = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_EnderecoFuncionario = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_CompFuncionario = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_CidadeFuncionario = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_CcFuncionario = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_PixFuncionario = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_FuncaoFuncionario = new System.Windows.Forms.TextBox();
            this.btn_InserirFuncionario = new System.Windows.Forms.Button();
            this.btn_AtualizarFuncionario = new System.Windows.Forms.Button();
            this.btn_ExcluirFuncionario = new System.Windows.Forms.Button();
            this.btn_Fechar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Funcionario)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // txt_IdFuncionario
            // 
            this.txt_IdFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_IdFuncionario.Location = new System.Drawing.Point(12, 25);
            this.txt_IdFuncionario.Name = "txt_IdFuncionario";
            this.txt_IdFuncionario.Size = new System.Drawing.Size(186, 20);
            this.txt_IdFuncionario.TabIndex = 1;
            // 
            // btn_LocalizarFuncionario
            // 
            this.btn_LocalizarFuncionario.BackColor = System.Drawing.Color.White;
            this.btn_LocalizarFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LocalizarFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LocalizarFuncionario.ForeColor = System.Drawing.Color.DarkGreen;
            this.btn_LocalizarFuncionario.Location = new System.Drawing.Point(246, 10);
            this.btn_LocalizarFuncionario.Name = "btn_LocalizarFuncionario";
            this.btn_LocalizarFuncionario.Size = new System.Drawing.Size(136, 47);
            this.btn_LocalizarFuncionario.TabIndex = 2;
            this.btn_LocalizarFuncionario.Text = "LOCALIZAR";
            this.btn_LocalizarFuncionario.UseVisualStyleBackColor = false;
            this.btn_LocalizarFuncionario.Click += new System.EventHandler(this.btn_LocalizarFuncionario_Click);
            // 
            // dgv_Funcionario
            // 
            this.dgv_Funcionario.AllowUserToAddRows = false;
            this.dgv_Funcionario.AllowUserToDeleteRows = false;
            this.dgv_Funcionario.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.dgv_Funcionario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Funcionario.Location = new System.Drawing.Point(15, 495);
            this.dgv_Funcionario.Name = "dgv_Funcionario";
            this.dgv_Funcionario.ReadOnly = true;
            this.dgv_Funcionario.Size = new System.Drawing.Size(940, 269);
            this.dgv_Funcionario.TabIndex = 3;
            this.dgv_Funcionario.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Funcionario_CellContentClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "NOME:";
            // 
            // txt_NomeFuncionario
            // 
            this.txt_NomeFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_NomeFuncionario.Location = new System.Drawing.Point(12, 90);
            this.txt_NomeFuncionario.Name = "txt_NomeFuncionario";
            this.txt_NomeFuncionario.Size = new System.Drawing.Size(421, 20);
            this.txt_NomeFuncionario.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(463, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "GÊNERO:";
            // 
            // txt_GeneroFuncionario
            // 
            this.txt_GeneroFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_GeneroFuncionario.Location = new System.Drawing.Point(466, 90);
            this.txt_GeneroFuncionario.Name = "txt_GeneroFuncionario";
            this.txt_GeneroFuncionario.Size = new System.Drawing.Size(64, 20);
            this.txt_GeneroFuncionario.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(9, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "CPF:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txt_CpfFuncionario
            // 
            this.txt_CpfFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_CpfFuncionario.Location = new System.Drawing.Point(12, 153);
            this.txt_CpfFuncionario.Name = "txt_CpfFuncionario";
            this.txt_CpfFuncionario.Size = new System.Drawing.Size(186, 20);
            this.txt_CpfFuncionario.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(232, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "DATA DE NASCIMENTO:";
            // 
            // txt_DataFuncionario
            // 
            this.txt_DataFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_DataFuncionario.Location = new System.Drawing.Point(235, 153);
            this.txt_DataFuncionario.Name = "txt_DataFuncionario";
            this.txt_DataFuncionario.Size = new System.Drawing.Size(198, 20);
            this.txt_DataFuncionario.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(463, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "CELULAR:";
            // 
            // txt_CelularFuncionario
            // 
            this.txt_CelularFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_CelularFuncionario.Location = new System.Drawing.Point(466, 153);
            this.txt_CelularFuncionario.Name = "txt_CelularFuncionario";
            this.txt_CelularFuncionario.Size = new System.Drawing.Size(198, 20);
            this.txt_CelularFuncionario.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "CEP:";
            // 
            // txt_CepFuncionario
            // 
            this.txt_CepFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_CepFuncionario.Location = new System.Drawing.Point(12, 217);
            this.txt_CepFuncionario.Name = "txt_CepFuncionario";
            this.txt_CepFuncionario.Size = new System.Drawing.Size(186, 20);
            this.txt_CepFuncionario.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 263);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "ENDEREÇO:";
            // 
            // txt_EnderecoFuncionario
            // 
            this.txt_EnderecoFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_EnderecoFuncionario.Location = new System.Drawing.Point(12, 279);
            this.txt_EnderecoFuncionario.Name = "txt_EnderecoFuncionario";
            this.txt_EnderecoFuncionario.Size = new System.Drawing.Size(421, 20);
            this.txt_EnderecoFuncionario.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(463, 263);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "COMPLEMENTO:";
            // 
            // txt_CompFuncionario
            // 
            this.txt_CompFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_CompFuncionario.Location = new System.Drawing.Point(466, 279);
            this.txt_CompFuncionario.Name = "txt_CompFuncionario";
            this.txt_CompFuncionario.Size = new System.Drawing.Size(198, 20);
            this.txt_CompFuncionario.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 323);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "CIDADE:";
            // 
            // txt_CidadeFuncionario
            // 
            this.txt_CidadeFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_CidadeFuncionario.Location = new System.Drawing.Point(12, 339);
            this.txt_CidadeFuncionario.Name = "txt_CidadeFuncionario";
            this.txt_CidadeFuncionario.Size = new System.Drawing.Size(186, 20);
            this.txt_CidadeFuncionario.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 385);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "CC:";
            // 
            // txt_CcFuncionario
            // 
            this.txt_CcFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_CcFuncionario.Location = new System.Drawing.Point(12, 401);
            this.txt_CcFuncionario.Name = "txt_CcFuncionario";
            this.txt_CcFuncionario.Size = new System.Drawing.Size(186, 20);
            this.txt_CcFuncionario.TabIndex = 23;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(232, 385);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "PIX:";
            // 
            // txt_PixFuncionario
            // 
            this.txt_PixFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_PixFuncionario.Location = new System.Drawing.Point(235, 401);
            this.txt_PixFuncionario.Name = "txt_PixFuncionario";
            this.txt_PixFuncionario.Size = new System.Drawing.Size(198, 20);
            this.txt_PixFuncionario.TabIndex = 25;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(9, 444);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "FUNÇÃO:";
            // 
            // txt_FuncaoFuncionario
            // 
            this.txt_FuncaoFuncionario.BackColor = System.Drawing.Color.White;
            this.txt_FuncaoFuncionario.Location = new System.Drawing.Point(12, 460);
            this.txt_FuncaoFuncionario.Name = "txt_FuncaoFuncionario";
            this.txt_FuncaoFuncionario.Size = new System.Drawing.Size(421, 20);
            this.txt_FuncaoFuncionario.TabIndex = 27;
            // 
            // btn_InserirFuncionario
            // 
            this.btn_InserirFuncionario.BackColor = System.Drawing.Color.White;
            this.btn_InserirFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InserirFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InserirFuncionario.Location = new System.Drawing.Point(748, 40);
            this.btn_InserirFuncionario.Name = "btn_InserirFuncionario";
            this.btn_InserirFuncionario.Size = new System.Drawing.Size(136, 47);
            this.btn_InserirFuncionario.TabIndex = 28;
            this.btn_InserirFuncionario.Text = "INSERIR";
            this.btn_InserirFuncionario.UseVisualStyleBackColor = false;
            this.btn_InserirFuncionario.Click += new System.EventHandler(this.btn_InserirFuncionario_Click);
            // 
            // btn_AtualizarFuncionario
            // 
            this.btn_AtualizarFuncionario.BackColor = System.Drawing.Color.White;
            this.btn_AtualizarFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AtualizarFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AtualizarFuncionario.Location = new System.Drawing.Point(748, 167);
            this.btn_AtualizarFuncionario.Name = "btn_AtualizarFuncionario";
            this.btn_AtualizarFuncionario.Size = new System.Drawing.Size(136, 47);
            this.btn_AtualizarFuncionario.TabIndex = 29;
            this.btn_AtualizarFuncionario.Text = "ATUALIZAR";
            this.btn_AtualizarFuncionario.UseVisualStyleBackColor = false;
            this.btn_AtualizarFuncionario.Click += new System.EventHandler(this.btn_AtualizarFuncionario_Click);
            // 
            // btn_ExcluirFuncionario
            // 
            this.btn_ExcluirFuncionario.BackColor = System.Drawing.Color.White;
            this.btn_ExcluirFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ExcluirFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ExcluirFuncionario.ForeColor = System.Drawing.Color.Red;
            this.btn_ExcluirFuncionario.Location = new System.Drawing.Point(748, 289);
            this.btn_ExcluirFuncionario.Name = "btn_ExcluirFuncionario";
            this.btn_ExcluirFuncionario.Size = new System.Drawing.Size(136, 47);
            this.btn_ExcluirFuncionario.TabIndex = 30;
            this.btn_ExcluirFuncionario.Text = "EXCLUIR";
            this.btn_ExcluirFuncionario.UseVisualStyleBackColor = false;
            this.btn_ExcluirFuncionario.Click += new System.EventHandler(this.btn_ExcluirFuncionario_Click);
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.BackColor = System.Drawing.Color.Red;
            this.btn_Fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Fechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Fechar.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.btn_Fechar.Location = new System.Drawing.Point(748, 410);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(136, 47);
            this.btn_Fechar.TabIndex = 31;
            this.btn_Fechar.Text = "FECHAR";
            this.btn_Fechar.UseVisualStyleBackColor = false;
            this.btn_Fechar.Click += new System.EventHandler(this.btn_Fechar_Click);
            // 
            // frm_Funcionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AntiqueWhite;
            this.ClientSize = new System.Drawing.Size(967, 776);
            this.Controls.Add(this.btn_Fechar);
            this.Controls.Add(this.btn_ExcluirFuncionario);
            this.Controls.Add(this.btn_AtualizarFuncionario);
            this.Controls.Add(this.btn_InserirFuncionario);
            this.Controls.Add(this.txt_FuncaoFuncionario);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_PixFuncionario);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txt_CcFuncionario);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_CidadeFuncionario);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_CompFuncionario);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_EnderecoFuncionario);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txt_CepFuncionario);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_CelularFuncionario);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_DataFuncionario);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_CpfFuncionario);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_GeneroFuncionario);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_NomeFuncionario);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgv_Funcionario);
            this.Controls.Add(this.btn_LocalizarFuncionario);
            this.Controls.Add(this.txt_IdFuncionario);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Funcionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Funcionário";
            this.Load += new System.EventHandler(this.frm_Funcionario_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Funcionario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_IdFuncionario;
        private System.Windows.Forms.Button btn_LocalizarFuncionario;
        private System.Windows.Forms.DataGridView dgv_Funcionario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_NomeFuncionario;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_GeneroFuncionario;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_CpfFuncionario;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_DataFuncionario;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_CelularFuncionario;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_CepFuncionario;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_EnderecoFuncionario;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_CompFuncionario;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_CidadeFuncionario;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_CcFuncionario;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_PixFuncionario;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_FuncaoFuncionario;
        private System.Windows.Forms.Button btn_InserirFuncionario;
        private System.Windows.Forms.Button btn_AtualizarFuncionario;
        private System.Windows.Forms.Button btn_ExcluirFuncionario;
        private System.Windows.Forms.Button btn_Fechar;
    }
}