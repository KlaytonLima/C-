﻿namespace BotecoTDS07
{
    partial class FrmProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProduto));
            this.btn_Fechar = new System.Windows.Forms.Button();
            this.btn_ExcluirProduto = new System.Windows.Forms.Button();
            this.btn_AtualizarProduto = new System.Windows.Forms.Button();
            this.btn_InserirProduto = new System.Windows.Forms.Button();
            this.txt_Preco = new System.Windows.Forms.TextBox();
            this.txt_Quantidade = new System.Windows.Forms.TextBox();
            this.txt_TipoProduto = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_NomeProduto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_IdProduto = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv_Produto = new System.Windows.Forms.DataGridView();
            this.btn_Localizar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Produto)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Fechar
            // 
            this.btn_Fechar.BackColor = System.Drawing.Color.PapayaWhip;
            this.btn_Fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Fechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Fechar.Location = new System.Drawing.Point(495, 208);
            this.btn_Fechar.Name = "btn_Fechar";
            this.btn_Fechar.Size = new System.Drawing.Size(130, 36);
            this.btn_Fechar.TabIndex = 31;
            this.btn_Fechar.Text = "FECHAR";
            this.btn_Fechar.UseVisualStyleBackColor = false;
            this.btn_Fechar.Click += new System.EventHandler(this.btn_Fechar_Click);
            // 
            // btn_ExcluirProduto
            // 
            this.btn_ExcluirProduto.BackColor = System.Drawing.Color.PapayaWhip;
            this.btn_ExcluirProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ExcluirProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ExcluirProduto.Location = new System.Drawing.Point(495, 145);
            this.btn_ExcluirProduto.Name = "btn_ExcluirProduto";
            this.btn_ExcluirProduto.Size = new System.Drawing.Size(130, 36);
            this.btn_ExcluirProduto.TabIndex = 30;
            this.btn_ExcluirProduto.Text = "EXCLUIR";
            this.btn_ExcluirProduto.UseVisualStyleBackColor = false;
            this.btn_ExcluirProduto.Click += new System.EventHandler(this.btn_ExcluirProduto_Click);
            // 
            // btn_AtualizarProduto
            // 
            this.btn_AtualizarProduto.BackColor = System.Drawing.Color.PapayaWhip;
            this.btn_AtualizarProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AtualizarProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AtualizarProduto.Location = new System.Drawing.Point(495, 78);
            this.btn_AtualizarProduto.Name = "btn_AtualizarProduto";
            this.btn_AtualizarProduto.Size = new System.Drawing.Size(130, 36);
            this.btn_AtualizarProduto.TabIndex = 29;
            this.btn_AtualizarProduto.Text = "ATUALIZAR";
            this.btn_AtualizarProduto.UseVisualStyleBackColor = false;
            this.btn_AtualizarProduto.Click += new System.EventHandler(this.btn_AtualizarProduto_Click);
            // 
            // btn_InserirProduto
            // 
            this.btn_InserirProduto.BackColor = System.Drawing.Color.PapayaWhip;
            this.btn_InserirProduto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InserirProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_InserirProduto.Location = new System.Drawing.Point(495, 18);
            this.btn_InserirProduto.Name = "btn_InserirProduto";
            this.btn_InserirProduto.Size = new System.Drawing.Size(130, 36);
            this.btn_InserirProduto.TabIndex = 28;
            this.btn_InserirProduto.Text = "INSERIR";
            this.btn_InserirProduto.UseVisualStyleBackColor = false;
            this.btn_InserirProduto.Click += new System.EventHandler(this.btn_InserirProduto_Click);
            // 
            // txt_Preco
            // 
            this.txt_Preco.Location = new System.Drawing.Point(9, 236);
            this.txt_Preco.Name = "txt_Preco";
            this.txt_Preco.Size = new System.Drawing.Size(158, 20);
            this.txt_Preco.TabIndex = 27;
            // 
            // txt_Quantidade
            // 
            this.txt_Quantidade.Location = new System.Drawing.Point(9, 184);
            this.txt_Quantidade.Name = "txt_Quantidade";
            this.txt_Quantidade.Size = new System.Drawing.Size(158, 20);
            this.txt_Quantidade.TabIndex = 26;
            // 
            // txt_TipoProduto
            // 
            this.txt_TipoProduto.Location = new System.Drawing.Point(9, 132);
            this.txt_TipoProduto.Name = "txt_TipoProduto";
            this.txt_TipoProduto.Size = new System.Drawing.Size(158, 20);
            this.txt_TipoProduto.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 15);
            this.label5.TabIndex = 24;
            this.label5.Text = "PREÇO:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 168);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 15);
            this.label4.TabIndex = 23;
            this.label4.Text = "QUANTIDADE:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 15);
            this.label3.TabIndex = 22;
            this.label3.Text = "TIPO:";
            // 
            // txt_NomeProduto
            // 
            this.txt_NomeProduto.Location = new System.Drawing.Point(9, 78);
            this.txt_NomeProduto.Name = "txt_NomeProduto";
            this.txt_NomeProduto.Size = new System.Drawing.Size(301, 20);
            this.txt_NomeProduto.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(9, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 20;
            this.label2.Text = "NOME:";
            // 
            // txt_IdProduto
            // 
            this.txt_IdProduto.Location = new System.Drawing.Point(12, 27);
            this.txt_IdProduto.Name = "txt_IdProduto";
            this.txt_IdProduto.Size = new System.Drawing.Size(155, 20);
            this.txt_IdProduto.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 15);
            this.label1.TabIndex = 18;
            this.label1.Text = "ID:";
            // 
            // dgv_Produto
            // 
            this.dgv_Produto.AllowUserToAddRows = false;
            this.dgv_Produto.AllowUserToDeleteRows = false;
            this.dgv_Produto.BackgroundColor = System.Drawing.Color.PapayaWhip;
            this.dgv_Produto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Produto.Location = new System.Drawing.Point(12, 278);
            this.dgv_Produto.Name = "dgv_Produto";
            this.dgv_Produto.ReadOnly = true;
            this.dgv_Produto.Size = new System.Drawing.Size(631, 255);
            this.dgv_Produto.TabIndex = 17;
            this.dgv_Produto.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Produto_CellContentClick);
            // 
            // btn_Localizar
            // 
            this.btn_Localizar.BackColor = System.Drawing.Color.PapayaWhip;
            this.btn_Localizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Localizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Localizar.Location = new System.Drawing.Point(180, 18);
            this.btn_Localizar.Name = "btn_Localizar";
            this.btn_Localizar.Size = new System.Drawing.Size(130, 36);
            this.btn_Localizar.TabIndex = 16;
            this.btn_Localizar.Text = "LOCALIZAR";
            this.btn_Localizar.UseVisualStyleBackColor = false;
            this.btn_Localizar.Click += new System.EventHandler(this.btn_Localizar_Click);
            // 
            // FrmProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Moccasin;
            this.ClientSize = new System.Drawing.Size(653, 547);
            this.Controls.Add(this.btn_Fechar);
            this.Controls.Add(this.btn_ExcluirProduto);
            this.Controls.Add(this.btn_AtualizarProduto);
            this.Controls.Add(this.btn_InserirProduto);
            this.Controls.Add(this.txt_Preco);
            this.Controls.Add(this.txt_Quantidade);
            this.Controls.Add(this.txt_TipoProduto);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_NomeProduto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_IdProduto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv_Produto);
            this.Controls.Add(this.btn_Localizar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmProduto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Produto";
            this.Load += new System.EventHandler(this.FrmProduto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Produto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Fechar;
        private System.Windows.Forms.Button btn_ExcluirProduto;
        private System.Windows.Forms.Button btn_AtualizarProduto;
        private System.Windows.Forms.Button btn_InserirProduto;
        private System.Windows.Forms.TextBox txt_Preco;
        private System.Windows.Forms.TextBox txt_Quantidade;
        private System.Windows.Forms.TextBox txt_TipoProduto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_NomeProduto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_IdProduto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgv_Produto;
        private System.Windows.Forms.Button btn_Localizar;
    }
}