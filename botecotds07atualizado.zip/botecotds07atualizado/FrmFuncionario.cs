﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BotecoTDS07
{
    public partial class frm_Funcionario : Form
    {
        public frm_Funcionario()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btn_LocalizarFuncionario_Click(object sender, EventArgs e)
        {

            if (txt_IdFuncionario.Text == "")
            {
                MessageBox.Show("Por favor, digite um ID válido!!!");
            }
            else
            {
                int Id = Convert.ToInt32(txt_IdFuncionario.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Localizar(Id);
                txt_NomeFuncionario.Text = funcionario.nome;
                txt_CelularFuncionario.Text = funcionario.celular;
                txt_EnderecoFuncionario.Text = funcionario.endereco;
                txt_CompFuncionario.Text = funcionario.complemento;
                txt_CidadeFuncionario.Text = funcionario.cidade;
                txt_CepFuncionario.Text = funcionario.cep;
                txt_CpfFuncionario.Text = funcionario.cpf;
                txt_CcFuncionario.Text = funcionario.cc;
                txt_PixFuncionario.Text = funcionario.pix;
                txt_GeneroFuncionario.Text = funcionario.genero;
                txt_DataFuncionario.Text = funcionario.data_nascimento;
                txt_FuncaoFuncionario.Text = funcionario.funcao;

                btn_AtualizarFuncionario.Enabled = true;
                btn_ExcluirFuncionario.Enabled = true;


                            }
        }

        private void btn_InserirFuncionario_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_NomeFuncionario.Text == "" && txt_CelularFuncionario.Text == "" && txt_EnderecoFuncionario.Text == "" && txt_CompFuncionario.Text == "" && txt_CidadeFuncionario.Text == "" && txt_CepFuncionario.Text == "" && txt_CpfFuncionario.Text == "" && txt_CcFuncionario.Text == "" && txt_PixFuncionario.Text == "" && txt_GeneroFuncionario.Text == "" && txt_DataFuncionario.Text == "" && txt_FuncaoFuncionario.Text == "")
                {
                    MessageBox.Show("Por favor, preencha o formulário!", "Campos Obrigatórios", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.txt_NomeFuncionario.Focus();
                }
                else
                {
                    Funcionario funcionario = new Funcionario();
                    if (funcionario.RegistroRepetido(txt_NomeFuncionario.Text, txt_CpfFuncionario.Text) != false)
                    {
                        MessageBox.Show("Este funcionário já existe em nossa base de dados!", "Funcionário Repetido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txt_NomeFuncionario.Text = "";
                        txt_CelularFuncionario.Text = "";
                        txt_EnderecoFuncionario.Text = "";
                        txt_CompFuncionario.Text = "";
                        txt_CidadeFuncionario.Text = "";
                        txt_CepFuncionario.Text = "";
                        txt_CpfFuncionario.Text = "";
                        txt_CcFuncionario.Text = "";
                        txt_PixFuncionario.Text = "";
                        txt_GeneroFuncionario.Text = "";
                        txt_DataFuncionario.Text = "";
                        txt_FuncaoFuncionario.Text = "";

                        this.txt_NomeFuncionario.Focus();

                    }
                    else
                    {
                        funcionario.Inserir(txt_NomeFuncionario.Text, txt_CelularFuncionario.Text, txt_EnderecoFuncionario.Text, txt_CompFuncionario.Text, txt_CidadeFuncionario.Text, txt_CepFuncionario.Text, txt_CpfFuncionario.Text, txt_CcFuncionario.Text, txt_PixFuncionario.Text, txt_GeneroFuncionario.Text, txt_DataFuncionario.Text, txt_FuncaoFuncionario.Text);
                        MessageBox.Show("Funcionario cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        List<Funcionario> funcionarios = funcionario.listafuncionario();
                        dgv_Funcionario.DataSource = funcionarios;
                        txt_NomeFuncionario.Text = "";
                        txt_CelularFuncionario.Text = "";
                        txt_EnderecoFuncionario.Text = "";
                        txt_CompFuncionario.Text = "";
                        txt_CidadeFuncionario.Text = "";
                        txt_CepFuncionario.Text = "";
                        txt_CpfFuncionario.Text = "";
                        txt_CcFuncionario.Text = "";
                        txt_PixFuncionario.Text = "";
                        txt_GeneroFuncionario.Text = "";
                        txt_DataFuncionario.Text = "";
                        txt_FuncaoFuncionario.Text = "";
                        
                        this.txt_NomeFuncionario.Focus();
                    }
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_AtualizarFuncionario_Click(object sender, EventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(txt_IdFuncionario.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Atualizar(txt_NomeFuncionario.Text, txt_CelularFuncionario.Text, txt_EnderecoFuncionario.Text, txt_CompFuncionario.Text, txt_CidadeFuncionario.Text, txt_CepFuncionario.Text, txt_CpfFuncionario.Text, txt_CcFuncionario.Text, txt_PixFuncionario.Text, txt_GeneroFuncionario.Text, txt_DataFuncionario.Text, txt_FuncaoFuncionario.Text);
                MessageBox.Show("Funcionário atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Funcionario> funcionarios = funcionario.listafuncionario();
                dgv_Funcionario.DataSource = funcionarios;
                txt_NomeFuncionario.Text = "";
                txt_CelularFuncionario.Text = "";
                txt_EnderecoFuncionario.Text = "";
                txt_CompFuncionario.Text = "";
                txt_CidadeFuncionario.Text = "";
                txt_CepFuncionario.Text = "";
                txt_CpfFuncionario.Text = "";
                txt_CcFuncionario.Text = "";
                txt_PixFuncionario.Text = "";
                txt_GeneroFuncionario.Text = "";
                txt_DataFuncionario.Text = ""; 

                this.txt_NomeFuncionario.Focus();
                btn_AtualizarFuncionario.Enabled = false;
                btn_ExcluirFuncionario.Enabled = false;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_ExcluirFuncionario_Click(object sender, EventArgs e)
        {
            try
            {
                int Id = Convert.ToInt32(txt_IdFuncionario.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Excluir(Id);
                MessageBox.Show("Funcionário excluído com sucesso!", "Excluir", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Funcionario> funcionarios = funcionario.listafuncionario();
                dgv_Funcionario.DataSource = funcionarios;
                txt_NomeFuncionario.Text = "";
                txt_CelularFuncionario.Text = "";
                txt_EnderecoFuncionario.Text = "";
                txt_CompFuncionario.Text = "";
                txt_CidadeFuncionario.Text = "";
                txt_CepFuncionario.Text = "";
                txt_CpfFuncionario.Text = "";
                txt_CcFuncionario.Text = "";
                txt_PixFuncionario.Text = "";
                txt_GeneroFuncionario.Text = "";
                txt_DataFuncionario.Text = ""; 

                this.txt_NomeFuncionario.Focus();
                btn_AtualizarFuncionario.Enabled = false;
                btn_ExcluirFuncionario.Enabled = false;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgv_Funcionario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgv_Funcionario.Rows[e.RowIndex];
                row.Selected = true;
                txt_IdFuncionario.Text = row.Cells[0].Value.ToString();
                txt_NomeFuncionario.Text = row.Cells[1].Value.ToString();
                txt_CelularFuncionario.Text = row.Cells[2].Value.ToString();
                txt_EnderecoFuncionario.Text = row.Cells[3].ToString();
                txt_CompFuncionario.Text = row.Cells[4].ToString();
                txt_CidadeFuncionario.Text = row.Cells[4].ToString();
                txt_CepFuncionario.Text = row.Cells[4].ToString();
                txt_CpfFuncionario.Text = row.Cells[4].ToString();
                txt_CcFuncionario.Text = row.Cells[4].ToString();
                txt_PixFuncionario.Text = row.Cells[4].ToString();
                txt_GeneroFuncionario.Text = row.Cells[4].ToString();
                txt_DataFuncionario.Text = row.Cells[4].ToString();
                txt_FuncaoFuncionario.Text = row.Cells[4].ToString();
            }
        }

        private void frm_Funcionario_Load(object sender, EventArgs e)
        {
            Funcionario funcionario = new Funcionario();
            List<Funcionario> funcionarios = funcionario.listafuncionario();
            dgv_Funcionario.DataSource = funcionarios;
            btn_AtualizarFuncionario.Enabled = false;
            btn_ExcluirFuncionario.Enabled = false;
        }
    }
}
